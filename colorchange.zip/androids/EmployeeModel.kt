package com.example.googlesignindemoforclient

data class EmployeeModel
    (
    var empId: String? = null,
    var empName:String? = null,
    var empAge:String? = null,
    var empSalary:String? = null,
)